
#define TIMEOUT	        2000 /* 2000 seems to be better than 750 for big CF cards */
#define SLEEP_TIMEOUT 	50
#define RETRIES         8

#define HPBS            1024*1

