/*
 * JPeg corrections table
 */
#ifndef DEFINE_IMAGE_H
#define DEFINE_IMAGE_H
 
int mdc800_correctImageData (unsigned char*, int,int,int );


#endif
