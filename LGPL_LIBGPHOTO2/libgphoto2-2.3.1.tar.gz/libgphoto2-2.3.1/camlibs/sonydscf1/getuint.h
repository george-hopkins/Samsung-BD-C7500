u_short get_u_short (u_char *buf);
u_int get_u_int (u_char *buf);
