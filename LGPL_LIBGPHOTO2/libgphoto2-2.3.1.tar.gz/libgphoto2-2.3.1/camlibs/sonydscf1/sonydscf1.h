#ifndef __SONYDSCF1_H__
#define __SONYDSCF1_H__

#define JPEG 0
#define JPEG_T 1
#define PMP 2
#define PMX 3

#endif /* __SONYDSCF1_H__ */
